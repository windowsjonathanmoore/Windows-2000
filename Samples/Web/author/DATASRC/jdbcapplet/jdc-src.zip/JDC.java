//=--------------------------------------------------------------------------=
// Copyright  1997  Microsoft Corporation.  All Rights Reserved.
//
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//=--------------------------------------------------------------------------=
//
// @(#)Java Data Connector - 03/25/97
//
// This applet exposes the OLE-DB Simple Provider API for access to
// JDBC Data Sources through the COM support in Internet Explorer 3.0
//

import java.applet.*;
import java.awt.*;
import java.sql.*;
import java.util.Vector;
import java.util.Enumeration;
import java.lang.Number;
import com.ms.osp.*;

////////////////////////////////////////////////////////////////////////////////
//
// CLASS JDC - Applet
//
//
public class JDC extends Applet
{
    //
    // Parameter Names
    //
    private final String PARAM_dbURL           = "dbURL";
    private final String PARAM_showUI          = "showUI";
    private final String PARAM_preloadRows     = "preloadRows";
    private final String PARAM_sqlStatement    = "sqlStatement";
    private final String PARAM_filterColumn    = "filterColumn";
    private final String PARAM_filterCriterion = "filterCriterion";
    private final String PARAM_filterValue     = "filterValue";
    private final String PARAM_allowInsert     = "allowInsert";
    private final String PARAM_allowDelete     = "allowDelete";
    private final String PARAM_allowUpdate     = "allowUpdate";
    private final String PARAM_driver          = "driver";
    private final String PARAM_user            = "user";
    private final String PARAM_password        = "password";

    private JDCSimpleProvider  m_jdcOSP    = null;  // OSP implementation
    private static boolean     m_debug     = false; // affects TRACE method
    private boolean            m_showUI    = true;
    private DataSourceListener m_dataSourceListener = null; // interface we consume so we can fire data change notifications

    private boolean m_dirtyDateSource = false;

    public JDC()
    {
        JDC.TRACE( "JDC ctor" );

            //
            // Register the Microsoft JDBC-ODBC Bridge Driver
            // Register the XDB Jet JDBC-ODBC Bridge Driver
            //
        try
        {
      	    Class.forName("com.ms.jdbc.odbc.JdbcOdbcDriver");
        }
        catch( Exception ex )
        {
            EXCEPTIONTRACE( ex, "Failed to initialize the Microsoft JDBC-ODBC bridge Driver" );
        }

        try
        {
      	    Class.forName("jet.bridge.JetDriver");
        }
        catch( Exception ex )
        {
            EXCEPTIONTRACE( ex, "Failed to initialize the XDB Jet JDBC-ODBC bridge Driver" );
        }
    }

    ////////////////////////////////////////
    // Method start
    // 
    public void start()
    {
        JDC.TRACE( "start()" );
        setVisible(m_showUI);
    }

    ////////////////////////////////////////
    // Method destroy
    // 
    public void destroy()
    {
        JDC.TRACE( "destroy()" );
    }

    ////////////////////////////////////////
    // Method init
    // 
    public void init()
    {
        JDC.TRACE( "init()" );

            //
            // create the OSP provider ( will initialize in init() method because that
            //   is where we have access to applet params)
            //
        try
        {
            m_jdcOSP = new JDCSimpleProvider( this, false, false, false );
        }
        catch( Exception ex )
        {
            EXCEPTIONTRACE( ex, "Failed to create OSP" );
            return;
        }

            //
            // Show user interface flag
            //
        String param = getParameter(PARAM_showUI);
        if (param != null)
            m_showUI = Boolean.valueOf(param).booleanValue();

            //
            // get parameters from container that affect data display and retrieval
            //
        param = getParameter(PARAM_dbURL);
        if (param != null)
            m_jdcOSP.getCriterion().setDbURL( param );

        param = getParameter(PARAM_preloadRows);
        if (param != null)
            m_jdcOSP.getCriterion().setPreloadRows( Integer.valueOf(param).intValue() );

        param = getParameter(PARAM_sqlStatement);
        if (param != null)
            m_jdcOSP.getCriterion().setSQLStatement( param );

        param = getParameter(PARAM_filterColumn);
        if (param != null)
            m_jdcOSP.getCriterion().setFilterColumn( param );

        param = getParameter(PARAM_filterCriterion);
        if (param != null)
            m_jdcOSP.getCriterion().setFilterCriterion( param );

        param = getParameter(PARAM_filterValue);
        if (param != null)
            m_jdcOSP.getCriterion().setFilterValue( param );

        param = getParameter(PARAM_user);
        if (param != null)
            m_jdcOSP.getCriterion().setUser( param );

        param = getParameter(PARAM_password);
        if (param != null)
            m_jdcOSP.getCriterion().setPassword( param );

        m_jdcOSP.getCriterion().setSortColumn     ( "" ); // bugbug: remove
        m_jdcOSP.getCriterion().setSortDirection  ( "" ); // bugbug: remove

            //
            // 
            //

        param = getParameter(PARAM_allowInsert);
        if (param != null)
            m_jdcOSP.setAllowInsert( Boolean.valueOf(param).booleanValue() );

        param = getParameter(PARAM_allowDelete);
        if (param != null)
            m_jdcOSP.setAllowDelete( Boolean.valueOf(param).booleanValue() );

        param = getParameter(PARAM_allowUpdate);
        if (param != null)
            m_jdcOSP.setAllowUpdate( Boolean.valueOf(param).booleanValue() );

        try
        {
                //
                // this starts the asynchronous preload of data...
                //
            m_jdcOSP.begin();

        }
        catch( Exception ex ) 
        { 
            m_jdcOSP = null;
            JDC.EXCEPTIONTRACE( ex, "Error initializing OSP provider"); 
        }
    }

    ////////////////////////////////////////
    // Method msDataSourceObject
    //
    // Function to provide the OSP interface to callers.
    // The qualifier parameter is ignored at this point, but is available
    // to allow the applet to serve up more than one data set in the future.
    //
    // @return the ISimpleTabularData provider
    //
    public Object msDataSourceObject(String qualifier)
    {
        JDC.TRACE( "msDataSourceObject()" );

        return m_jdcOSP;
    }

    ////////////////////////////////////////
    // Method msDATASRCObject
    //
    // Function to provide the OSP interface to callers.
    // The qualifier parameter is ignored at this point, but is available
    // to allow the applet to serve up more than one data set in the future.
    //
    // @return the ISimpleTabularData provider
    //
    public Object msDATASRCObject(String qualifier)
    {
        JDC.TRACE( "msDATASRCObject()" );

        try
        {
            m_jdcOSP.waitForPreloadBegin();
        }
        catch( Exception ex )
        {
            JDC.EXCEPTIONTRACE( ex, "Error waiting for preload" );
        }

        return m_jdcOSP;
    }

    ////////////////////////////////////////
    // Method addDataSourceListener
    //
    // interface DataSource
    //
    // @param data souce listener, only one listener is supported.
    //
    public void addDataSourceListener(DataSourceListener listener)
        throws java.util.TooManyListenersException
    {
        JDC.TRACE( "addDataSourceListener()" );

        if( m_dataSourceListener != null )
            throw new java.util.TooManyListenersException();

        m_dataSourceListener = listener;
    }

    ////////////////////////////////////////
    // Method removeDataSourceListener
    //
    // interface DataSource
    //
    // @param data souce listener, consumers of OSP *must* call this
    //          if they no longer require notification
    //
    public void removeDataSourceListener(DataSourceListener listener)
    {
        JDC.TRACE( "removeDataSourceListener()" );
        m_dataSourceListener = null;
    }
    
    ////////////////////////////////////////
    // Method notifyListeners
    //
    // This function should probably be private, but for
    // now leave public so script writer can call to test notifications
    //
    public void notifyListeners()
        throws Exception
    {
        JDC.TRACE( "notifyListeners()" );

        if( m_dataSourceListener == null )
            return;

            //
            // if m_jdcOSP is null, we pass false to second param
            // this signifies that the data is changed, but not available
            //
        m_dataSourceListener.dataMemberChanged( "" );
    }

    ////////////////////////////////////////
    // Method getDataSourceListener
    //
    public DataSourceListener getDataSourceListener()
    {
        return m_dataSourceListener;
    }

    ////////////////////////////////////////
    // Method commitChanges
    //
    // Not implemented. Because our dataset may not correspond to a physical
    // table, we can't effectively implement commitChanges in a generic fashion.
    // You must implement this if you want to commit any changes made to
    // the data.
    //
    public void commitChanges() 
        throws Exception
    {
        throw new NotImplementedException();
    }

    ////////////////////////////////////////
    // Method apply
    //
    // Applies any pending sorting and filtering criteria.
    //
    public void apply()
        throws Exception
    {
        JDC.TRACE( "apply()" );

        if( m_dirtyDateSource )
        {
                //
                // create a nrand new OSP provider object
                //
            JDCSimpleProvider jdcOSP = new JDCSimpleProvider( this, false, false, false );

                //
                // set properties before calling begin()
                //
            jdcOSP.getCriterion().setDbURL          ( m_jdcOSP.getCriterion().getDbURL          () );
            jdcOSP.getCriterion().setPreloadRows    ( m_jdcOSP.getCriterion().getPreloadRows    () );
            jdcOSP.getCriterion().setSQLStatement   ( m_jdcOSP.getCriterion().getSQLStatement   () );
            jdcOSP.getCriterion().setSortColumn     ( m_jdcOSP.getCriterion().getSortColumn     () );
            jdcOSP.getCriterion().setSortDirection  ( m_jdcOSP.getCriterion().getSortDirection  () );
            jdcOSP.getCriterion().setFilterColumn   ( m_jdcOSP.getCriterion().getFilterColumn   () );
            jdcOSP.getCriterion().setFilterCriterion( m_jdcOSP.getCriterion().getFilterCriterion() );
            jdcOSP.getCriterion().setFilterValue    ( m_jdcOSP.getCriterion().getFilterValue    () );
            jdcOSP.getCriterion().setUser           ( m_jdcOSP.getCriterion().getUser           () );
            jdcOSP.getCriterion().setPassword       ( m_jdcOSP.getCriterion().getPassword       () );

            jdcOSP.setAllowInsert( m_jdcOSP.getAllowInsert() );
            jdcOSP.setAllowDelete( m_jdcOSP.getAllowDelete() );
            jdcOSP.setAllowUpdate( m_jdcOSP.getAllowUpdate() );

                //
                // orphan existing m_jdcOSP, by setting out member to the new one
                //
            m_jdcOSP = jdcOSP;

                //
                // starts asynch download
                //
            m_jdcOSP.begin();

                //
                // will fire data shape change notification, msDataSourceObject
                //
            notifyListeners();  
        }
        else
        {
                //
                // simply re-apply any sorting or filtering criteria
                //
            m_jdcOSP.apply();
            notifyListeners();  
        }
    }

    ////////////////////////////////////////
    // getInserted
    // getDeleted
    // getDirty
    //
    // @return the Java enumeration containing the
    //      JDCRow objects that match the specified
    //      criteria (as defined by the method name)
    public Enumeration getInserted()
        { return m_jdcOSP.getInserted(); }

    public Enumeration getDeleted()
        { return m_jdcOSP.getDeleted(); }

    public Enumeration getDirty()
        { return m_jdcOSP.getDirty(); }

    ////////////////////////////////////////
    // 
    // APPLET PROPERTIES
    //
    ////////////////////////////////////////
    public boolean getDebug()
        { return m_debug; }

    public void setDebug( boolean dbg )
        { m_debug = dbg; }

    public String getDbURL()
        { return m_jdcOSP.getCriterion().getDbURL(); }

    public void setDbURL( String dbURL )
    { 
        m_jdcOSP.getCriterion().setDbURL( dbURL ); 
        m_dirtyDateSource = true;
    }

    public boolean getShowUI()
        { return m_showUI; }

    public void setShowUI( boolean show )
        { m_showUI = show; setVisible(show); }

    public int getPreloadRows()
        { return m_jdcOSP.getCriterion().getPreloadRows(); }

    public void setPreloadRows( int preload )
        { m_jdcOSP.getCriterion().setPreloadRows( preload ); }

    public String getSQLStatement()
        { return m_jdcOSP.getCriterion().getSQLStatement(); }

    public void setSQLStatement( String sqlStatement )
    { 
        m_jdcOSP.getCriterion().setSQLStatement( sqlStatement ); 
        m_dirtyDateSource = true;
    }

    public String getSortColumn()
        { return m_jdcOSP.getCriterion().getSortColumn(); }

    public void setSortColumn( String sortCol )
        { m_jdcOSP.getCriterion().setSortColumn( sortCol ); }

    public String getSortDirection()
        { return m_jdcOSP.getCriterion().getSortDirection(); }

    public void setSortDirection( String sortDir )
        { m_jdcOSP.getCriterion().setSortDirection( sortDir ); }

    public String getFilterColumn()
        { return m_jdcOSP.getCriterion().getFilterColumn(); }

    public void setFilterColumn( String filtCol )
        { m_jdcOSP.getCriterion().setFilterColumn( filtCol ); }

    public String getFilterCriterion()
        { return m_jdcOSP.getCriterion().getFilterCriterion(); }

    public void setFilterCriterion( String filterCrit )
    { 
        m_jdcOSP.getCriterion().setFilterCriterion( filterCrit ); 
    }

    public String getFilterValue()
        { return m_jdcOSP.getCriterion().getFilterValue(); }

    public void setFilterValue( String filtVal )
        { m_jdcOSP.getCriterion().setFilterValue( filtVal ); }

    public boolean getAllowInsert()
        { return m_jdcOSP.getAllowInsert(); }

    public void setAllowInsert( boolean allowInsert )
        { m_jdcOSP.setAllowInsert( allowInsert ); }

    public boolean getAllowDelete()
        { return m_jdcOSP.getAllowDelete(); }

    public void setAllowDelete( boolean allowDelete )
        { m_jdcOSP.setAllowDelete( allowDelete ); }

    public boolean getAllowUpdate()
        { return m_jdcOSP.getAllowUpdate(); }

    public void setAllowUpdate( boolean allowUpdate )
        { m_jdcOSP.setAllowUpdate( allowUpdate ); }

    public String getUser()
        { return m_jdcOSP.getUser(); }

    public void setUser( String userName )
    { 
        m_jdcOSP.setUser( userName ); 
        m_dirtyDateSource = true;
    }

    public String getPassword()
        { return m_jdcOSP.getPassword(); }

    public void setPassword( String userPassword )
    { 
        m_jdcOSP.setPassword( userPassword ); 
        m_dirtyDateSource = true;
    }

    ////////////////////////////////////////
    // Method TRACE
    //
    // @param the string to print to the console
    //
    public static void TRACE( String str )
    {
        if( m_debug )
            System.out.println( "JDCMSG: " + str );
    }

    ////////////////////////////////////////
    // Method EXCEPTIONTRACE
    //
    // @param the exception in which we want to write out the return value of 
    public static void EXCEPTIONTRACE( Exception ex, String str )
    {
        TRACE( "JDCMSG: " + str + ": " + ex.toString() );
    }

    ////////////////////////////////////////
    // Method getAppletInfo
    // 
    // @return a string describing the applet
    public String getAppletInfo()
    {
        return "Name: Java Data Connector (JDC)\r\n" +
               "Author: Microsoft Corporation\r\n" +
               "Created with Microsoft Visual J++ Version 1.1\r\n" +
               "\r\n" +
               "This applet exposes the OLE-DB Simple Provider API for access to\r\n" +
               "JDBC Data Sources through the COM support in Internet Explorer" +
               "\n";
    }

    ////////////////////////////////////////
    // Method getParameterInfo
    // 
    // @return information about this applet's parameters in an array of string arrays
    //
    public String[][] getParameterInfo()
    {
        String[][] info =
        {
            { PARAM_dbURL,           "String",  "The data source specified as a JDBC URL" },
            { PARAM_showUI,          "boolean", "Determines if the applet will be a visible element on the HTML form." },
            { PARAM_preloadRows,     "int",     "Number of rows to preload before loading asynchronously" },
            { PARAM_sqlStatement,    "String",  "The SQL Statement used to retrieve data from the specified data source" },
            { PARAM_filterColumn,    "String",  "Column index or name to filter on" },
            { PARAM_filterCriterion, "String",  "Comparison operator for filter, <, <=, +, >=, >, !=" },
            { PARAM_filterValue,     "String",  "Value to compare with data in column FilterColumn and operator in filterCriterion" },
            { PARAM_allowInsert,     "boolean", "Allow insert operations to succeed off calls to OSP." },
            { PARAM_allowDelete,     "boolean", "Allow delete operations to succeed off calls to OSP." },
            { PARAM_allowUpdate,     "boolean", "Allow update operations to succeed off calls to OSP." },
            { PARAM_driver,          "String",  "JDBC Bridge driver to use." },
            { PARAM_user,            "String",  "Login id to data source." },
            { PARAM_password,        "String",  "Login password to data source." }
        };
        return info;        
    }
} // JDC


















////////////////////////////////////////////////////////////////////////////////
//
// CLASS JDCSimpleProvider - Implements OLEDBSimpleProvider
//
// Notes: * The JDBC-specific code is located in JDCDataAccess
//
//
class JDCSimpleProvider implements OLEDBSimpleProvider
{
    private boolean m_allowInsert = false;
    private boolean m_allowDelete = false;
    private boolean m_allowUpdate = false;

    private JDCDataAccess               m_jdcAccess   = null;
    private OLEDBSimpleProviderListener m_OSPListener = null;
    private JDC                         m_jdc         = null;

    ////////////////////////////////////////
    // ctor
    //
    // ctor is called in the init() method of the applet
    //
    public JDCSimpleProvider( JDC jdc,
        boolean allowInsert, boolean allowDelete, boolean allowUpdate )
        throws Exception
    {
        m_jdc = jdc;
        m_allowInsert = allowInsert;
        m_allowDelete = allowDelete;
        m_allowUpdate = allowUpdate;

            //
            // Create the object that will actually access JDBC
            //
        m_jdcAccess = new JDCDataAccess(this);
    }

    ////////////////////////////////////////
    // method begin()
    //
    // Called after all properties on m_jdcAccess have been set
    //
    public void begin() 
        throws Exception
    {
        m_jdcAccess.connect();
        m_jdcAccess.executeSQL();
    }

    ////////////////////////////////////////
    // Method getCriterion
    //
    // @return the jdbc-specific object, but limits access to 
    //   methods on this interface
    //
    public ICustomCriterion getCriterion()
    {
        return m_jdcAccess;
    }

    ////////////////////////////////////////
    // Method apply
    //
    // Applies any pending sorting and filtering criteria.
    //
    public void apply()
        throws Exception
    {
        m_jdcAccess.quicksortRowset();
    }

    ////////////////////////////////////////
    // Method waitForPreloadBegin
    //
    // Waits for preload to begin
    //
    public void waitForPreloadBegin()
        throws InterruptedException
    {
        m_jdcAccess.waitForPreloadBegin();
    }
    
    ////////////////////////////////////////
    // getOSPListener
    //
    // @return the current OLEDBSimpleProviderListener
    //
    public OLEDBSimpleProviderListener getOSPListener()
    {
        JDC.TRACE( "getOSPListener()" );
        return m_OSPListener;
    }

    ////////////////////////////////////////
    // DataSourceListener
    //
    // see jdc
    //
    public DataSourceListener getDataSourceListener()
    {
        return m_jdc.getDataSourceListener();
    }
    
    ////////////////////////////////////////
    // Method addOLEDBSimpleProviderListener
    //
    // interface OLEDBSimpleProvider
    //
    public void addOLEDBSimpleProviderListener(OLEDBSimpleProviderListener listener )
    {
        JDC.TRACE( "addOLEDBSimpleProviderListener()" );
        m_OSPListener = listener;
    }

    ////////////////////////////////////////
    // Method removeOLEDBSimpleProviderListener
    //
    // interface OLEDBSimpleProvider
    //
    public void removeOLEDBSimpleProviderListener(OLEDBSimpleProviderListener listener )
    {
        JDC.TRACE( "removeOLEDBSimpleProviderListener()" );
        if( m_OSPListener == listener )
            m_OSPListener = null;
    }

    ////////////////////////////////////////
    // stopTransfer
    //
    // interface OLEDBSimpleProvider
    //
    public void stopTransfer()
    {
        JDC.TRACE( "stopTransfer()" );
        m_jdcAccess.stopTransfer();
    }

    ////////////////////////////////////////
    // isAsync
    //
    // interface OLEDBSimpleProvider
    //
    // @return 
    //
    public int isAsync()
    {
        JDC.TRACE( "isAsync() returning 1" );
        return 1;
    }

    ////////////////////////////////////////
    // getEstimatedRows
    //
    // interface OLEDBSimpleProvider
    //
    // @return 
    //
    public int getEstimatedRows()
    {
        int nEst = m_jdcAccess.getEstimatedRows();
        JDC.TRACE( "getEstimatedRows() returning " + Integer.toString(nEst));
        return nEst;
    }

    ////////////////////////////////////////
    // Method getRowCount
    //
    // interface OLEDBSimpleProvider
    //
    // @return number of rows in the dataset
    //
    public int getRowCount()
    {
        int rowCount = m_jdcAccess.getRowCount();
        JDC.TRACE( "getRowCount() returning " + Integer.toString(rowCount));
        return rowCount;
    }

    ////////////////////////////////////////
    // Method getColumnCount
    //
    // interface OLEDBSimpleProvider
    //
    // @return number of columns in the dataset
    // 
    public int getColumnCount() 
    {
        int col = m_jdcAccess.getColumnCount();
        JDC.TRACE( "getColumnCount(" + Integer.toString(col) + ")" );
        return col;
    }

    ////////////////////////////////////////
    // Method getRWStatus
    // 
    // interface OLEDBSimpleProvider
    //
    // @param row and column where 1st row/col has index 1, second 2, etc.
    // @return the read/write status of the secified cell as below:
    // 
    // STDRW_DEFAULT   = 1,
    // STDRW_READONLY  = 0,    // readonly
    // STDRW_READWRITE = 1,    // readwrite
    // STDRW_MIXED     = 2     // mixed or unknown; most callers will treat
    //                         //  as READWRITE "Lazy" provider should just
    //                         //  return STDRW_MIXED

    public int getRWStatus( int row, int col ) 
    {
        JDC.TRACE( "getRWStatus(" + Integer.toString(row) + "," +
            Integer.toString(col) + ")" );

            //
            // if row or col is 0, we return read-only because this is
            // column and row header information
            //
        if( 0 == row || 0 == col )
            return OSPRW.OSPRW_READONLY;
       
            //
            // for row == -1, we request rw status of specified column
            // for col == -1, we request rw status of specified row
            //
        if (-1 == row || -1 == col)
            return OSPRW.OSPRW_MIXED;

            //
            // If allow updated, return STDRW_READWRITE, otherwise STDRW_READONLY
            //
        if( m_allowUpdate )
            return OSPRW.OSPRW_READWRITE;
        else
            return OSPRW.OSPRW_READONLY;
    }

    ////////////////////////////////////////
    // Method getVariant
    //
    // interface OLEDBSimpleProvider
    //
    //   @param row, col, format
    //          row/col are 1-based
    //          format is as specified below:
    //
    //          STDFORMAT_RAW = 0,        // set/get variant as is
    //          STDFORMAT_DEFAULT = 0,    // default is RAW
    //          STDFORMAT_FORMATTED = 1,  // all variants converted to string representation
    //          STDFORMAT_HTML = 2        // variant converted to HTML string representation
    //                                    // (providers not required to implement this).
    //
    //   @return the value of the specified cell as a Variant
    // 
    public Object getVariant( int row, int col, int format ) 
    {
        try
        {
            Object obj = m_jdcAccess.getValue( row, col );

            switch( format )
            {
                case OSPFORMAT.OSPFORMAT_HTML :// HTML formatted
                case OSPFORMAT.OSPFORMAT_FORMATTED :// String formatted
                    {
                        String str = obj.toString();
                        //JDC.TRACE( "getVariant(" + Integer.toString(row) + "," +
                        //    Integer.toString(col) + "," + Integer.toString(format) + ") returns " + str );
                        return str;
                    }
                default:
                    {
                        //JDC.TRACE( "getVariant(" + Integer.toString(row) + "," +
                        //    Integer.toString(col) + "," + Integer.toString(format) + ") returns " + obj.toString() );
                        return obj;
                    }
            }
        }
        catch( Exception ex )
        {
            throw new com.ms.osp.IllegalArgumentException();
        }
    }

    ////////////////////////////////////////
    // Method setVariant
    //
    // interface OLEDBSimpleProvider
    //
    // @param  row, col are 1-based
    //         format is as specified in GetVariant
    //         var is the value ot place in the specified cell
    // @return none
    //
    public void setVariant( int row, int col, int format, Object var )
    {
        JDC.TRACE( "setVariant()" );

            //
            // bugbug: need to interpret format parameter
            //
        if( m_allowUpdate )
        {
            try
            {
                if( m_OSPListener != null )
                    m_OSPListener.aboutToChangeCell( row, col );

                JavaVariant v = new JavaVariant( var );
                m_jdcAccess.setVariant( row, col, v );

                if( m_OSPListener != null )
                    m_OSPListener.cellChanged( row, col );

            }
            catch( Exception ex )
            {
                throw new com.ms.osp.IllegalArgumentException();
            }        
        }
    }

    ////////////////////////////////////////
    // Method getLocale
    // 
    // interface OLEDBSimpleProvider
    //
    // @return the locale
    //
    public String getLocale()
    {
        JDC.TRACE( "getLocale()" );

        return "";
    }

    ////////////////////////////////////////
    // Method deleteRows
    //
    // interface OLEDBSimpleProvider
    //
    // @return the number of rows successfully deleted
    //
    public int deleteRows( int row, int numRows )
    {
        JDC.TRACE( "deleteRows()" );

        if( m_allowDelete )
        {
            try
            {
                if( m_OSPListener != null )
                    m_OSPListener.aboutToDeleteRows( row, numRows );

                int numDeleted = m_jdcAccess.deleteRows( row, numRows );

                    //
                    // we don't fire if we did not actually delete any rows
                    //
                if( numDeleted > 0 && m_OSPListener != null )
                    m_OSPListener.deletedRows(row,numDeleted);

                return numDeleted;
            }
            catch( Exception ex ) 
            { 
                JDC.EXCEPTIONTRACE( ex, "Exception in DeleteRows()"); 
            }
        }

        throw new AccessDeniedException();
    }

    ////////////////////////////////////////
    // Method insertRows
    // 
    // interface OLEDBSimpleProvider
    //
    // @param row is 1-based, numrows specified the number of
    //   rows to insert where first of these rows will be at index row
    // @return the number of rows successfully inserted
    //
    public int insertRows( int row, int numRows )
    {
        JDC.TRACE( "insertRows()" );

        if( m_allowInsert )
        {
            try
            {
                if( m_OSPListener != null )
                    m_OSPListener.aboutToInsertRows( row, numRows );

                int numInserted = m_jdcAccess.insertRows( row, numRows );
            
                if( numInserted > 0 && m_OSPListener != null )
                    m_OSPListener.insertedRows( row, numInserted );

                return numInserted;
            }
            catch( Exception ex ) 
            { 
                JDC.EXCEPTIONTRACE( ex, "Exception in InsertRows()"); 
            }
        }

        throw new AccessDeniedException();
    }

    ////////////////////////////////////////
    // Method deleteColumns
    // 
    // interface OLEDBSimpleProvider
    //
    // @param iColumn is 1-based, cColumns is the number of columns to delete
    // @return the number of columns actually deleted
    //
    public int deleteColumns( int iColumn, int cColumns )
    {
        JDC.TRACE( "deleteColumns()" );

        throw new NotImplementedException();
    }

    ////////////////////////////////////////
    // Method insertColumns
    // 
    // interface OLEDBSimpleProvider
    //
    // @param iColumn is 1-based, cColumns is the number of columns to insert
    // @return the number of columns actually inserted
    //
    public int insertColumns( int iColumn, int cColumns )
    {
        JDC.TRACE( "insertColumns()" );

        throw new NotImplementedException();
    }

    ////////////////////////////////////////
    // Method Find
    //
    // interface OLEDBSimpleProvider
    //
    // @param iRowStart is the 1-based row index to begin the search
    //        for each row, compare cell in column iColumn with Variant val
    //        findFlags denote whether we do a case-sensitive compare or not
    //        compType is <, <=, =, etc
    // @return the number of columns actually inserted

    public int find( int iRowStart, int iColumn, Object val, int findFlags, int compType )
    {
        JDC.TRACE( "find()" );

        try
        {
            // bugbug: replace JavaVariant ctor arg to straight Object
            JavaVariant v = new JavaVariant( val.toString() );
            return m_jdcAccess.find( iRowStart, iColumn, v, findFlags, compType );
        }
        catch( Exception ex )
        {
            JDC.EXCEPTIONTRACE( ex, "Error in Find()" );
            throw new com.ms.osp.IllegalArgumentException();
        }
    }

    ////////////////////////////////////////
    // getInserted, getDeleted, getDirty
    //
    // getInserted
    // getDeleted
    // getDirty
    //
    public Enumeration getInserted()
        { return m_jdcAccess.getInserted(); }

    public Enumeration getDeleted()
        { return m_jdcAccess.getDeleted(); }

    public Enumeration getDirty()
        { return m_jdcAccess.getDirty(); }

    ////////////////////////////////////////
    // allowInsert Property
    //
    public boolean getAllowInsert()
        { return m_allowInsert; }

    public void setAllowInsert( boolean allowInsert )
        { m_allowInsert = allowInsert; }

    ////////////////////////////////////////
    // allowDelete Property
    //
    public boolean getAllowDelete()
        { return m_allowDelete; }

    public void setAllowDelete( boolean allowDelete )
        { m_allowDelete = allowDelete; }

    ////////////////////////////////////////
    // allowUpdate Property
    //
    public boolean getAllowUpdate()
        { return m_allowUpdate; }

    public void setAllowUpdate( boolean allowUpdate )
        { m_allowUpdate = allowUpdate; }

    ////////////////////////////////////////
    // user Property
    //
    public String getUser()
        { return m_jdcAccess.getUser(); }

    public void setUser( String userName )
        { m_jdcAccess.setUser( userName ); }

    ////////////////////////////////////////
    // user Property
    //
    public String getPassword()
        { return m_jdcAccess.getPassword(); }

    public void setPassword( String userPassword )
        { m_jdcAccess.setPassword( userPassword ); }

} // class JDCSimpleProvider





