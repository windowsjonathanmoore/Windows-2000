//=--------------------------------------------------------------------------=
// Copyright  1997  Microsoft Corporation.  All Rights Reserved.
//
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//=--------------------------------------------------------------------------=
//
// @(#)JDCDataAccess Layer - 03/25/97
//
// Part of the Java Data Connector
//
// JDCDataAccess performs all JDBC-specific calls
//

import java.sql.*;
import java.util.Vector;
import java.util.Enumeration;
import com.ms.osp.*;
import com.ms.osp.IllegalArgumentException;

////////////////////////////////////////////////////////////////////////////////
//
// interface ICustomCriteria
//
//
interface ICustomCriterion
{
	public String  getDbURL();
	public void    setDbURL( String dburl );
	public int     getPreloadRows();
	public void    setPreloadRows( int iPreload );
	public String  getSQLStatement();
	public void    setSQLStatement( String sqlStatement );
	public String  getSortColumn();
	public void    setSortColumn( String sortCol );
	public String  getSortDirection();
	public void    setSortDirection( String sortDir );
	public String  getFilterColumn();
	public void    setFilterColumn( String filtCol );
	public String  getFilterCriterion();
	public void    setFilterCriterion( String filterCrit );
	public String  getFilterValue();
	public void    setFilterValue( String filtVal );
	public String  getUser();
	public void    setUser( String userName );
	public String  getPassword();
	public void    setPassword( String userPassword );

};

////////////////////////////////////////////////////////////////////////////////
//
// class JDCDataAccess
//
//
class JDCDataAccess implements Runnable, ICustomCriterion
{
    ////////////////////////////////////////////////////////////////////////////////
    // Member Variable Declarations
    ////////////////////////////////////////////////////////////////////////////////

    //
    // JDBC access objects
    //
	private Connection m_connection = null;
	private Statement  m_statement  = null;
	private ResultSet  m_resultSet  = null;
	private ResultSetMetaData m_rsMeta = null;

    //
    // members for ICustomCriterion
    //
	private String  m_dbURL = "";
	private boolean m_showUI = true;
	private int     m_preloadRows = 0;
	private String  m_sqlStatement = "";
	private String  m_sortColumn = "";
	private int     m_sortDir = 1; // 1 or -1 for ascending/descending
    private String  m_filterColumn = "";
    private int     m_filterColumnIndex = -1;
	private int     m_filterCriterion = -1;
    private String  m_filterValue = "";
	private JavaVariant m_filterValueVariant = null;

    private String  m_userName = "";
    private String  m_userPassword = "";

    // string representations of comparison operators
    private String  m_filterCriterionStrings[] = 
        { "", "=", "<", "<=", ">=", ">", "!=" };

    // cache of resultset
	private JDCRowset  m_jdcRowset  = null;
    
    // jdc provider we supply data to
    private JDCSimpleProvider m_jdcProvider     = null;

    // asynchronous row load support 
    private Thread            m_async           = null; 

    // for use by quicksort
    private int               m_qsColIndex      = -1;

    // for cropping vector into usable sections (to set before deleted rows
    // which quicksort puts at end, for instance)
    private int               m_useableRowsetSize = 0;

    private boolean           m_fContinueTransfer = true;


	////////////////////////////////////////
	// ctor
	//
	// jdcProvider is the OSP provider
    //
	public JDCDataAccess( JDCSimpleProvider jdcProvider )
	{
        m_jdcProvider = jdcProvider;
        m_async = new Thread( this );
	}

	////////////////////////////////////////
	// connect
	//
	// connects to the target data source
	//
	public void connect( )
		throws Exception
	{
        clearSqlObjects();

		m_connection = DriverManager.getConnection( m_dbURL, m_userName, m_userPassword );
	}

	////////////////////////////////////////
	// clearSqlObjects
	//
	//
	private void clearSqlObjects( )
    {
		m_connection= null;
		m_statement = null;
		m_resultSet = null;
		m_rsMeta    = null;
        m_jdcRowset = null;

        m_fContinueTransfer = true;
    }

	////////////////////////////////////////
	// Method waitForPreloadBegin
	//
	// Waits for preload to begin
	//
	public void waitForPreloadBegin()
        throws InterruptedException
    {
        synchronized( m_async )
        {
            m_async.wait();
        }
        int i=0;
    }

	////////////////////////////////////////
    //
	// interface Runnable Implementation (Asynchronous loading performed here)
	//
	// We don't specifically synchronize access to rowset here because loadNextRow()
    //   will do that. The exception is the section of code that 'preloads' the data.
    //   we want to block for that entire session
    //
    public void run()
    {
		JavaVariant v = new JavaVariant();
        boolean success = true;

            //
            // BUGBUG : This code will pause asynch load of data
            // long enough for ie to call addOLEDBSimpleprovider...
            //
        /*try
        {
            Thread.sleep( 2000 );
        }
        catch( Exception ex )
        {
            JDC.EXCEPTIONTRACE( ex, "run()" );
        }*/

        m_useableRowsetSize = 0;
		m_jdcRowset.ensureCapacity(m_preloadRows);

            // PRELOAD SESSION
            //
            // For the entire preload session, we lock on m_jdcRowset
            // will then block because it tries to get a lock as well
            //

        synchronized( m_jdcRowset )
        {
            while( success && m_fContinueTransfer &&
			       (m_preloadRows == 0 || m_useableRowsetSize < m_preloadRows) )
            {
                success = loadNextRow();
                if( success )
                    m_useableRowsetSize++;
            }

        }

        synchronized( m_async )
        {
            JDC.TRACE( "Finished preload of data" );
            m_async.notifyAll();
        }   

        OLEDBSimpleProviderListener osplistener = m_jdcProvider.getOSPListener();

            //
            // let OSP listener know that we have data available
            //
        if( osplistener != null )
        {
            JDC.TRACE( "Firing rowsAvailable" );
            osplistener.rowsAvailable( 1, m_useableRowsetSize );
        }

            //
            // read in the remaining rows
            //
        while (success && m_fContinueTransfer )
        {
                //
                // prevent access to rowset while we are reading a new row
                //
            success = loadNextRow();
            if( success )
                m_useableRowsetSize++;
        }

        JDC.TRACE( "Finished load of all data" );

        if( osplistener != null )
        {
            JDC.TRACE( "Firing transfer complete" );
            if( m_fContinueTransfer )
                osplistener.transferComplete( OSPXFER.OSPXFER_COMPLETE );
            else
                osplistener.transferComplete( OSPXFER.OSPXFER_ABORT );
        }

        m_fContinueTransfer = false;
    }

	////////////////////////////////////////
    // getInserted
    // getDeleted
    // getDirty
    //
    public Enumeration getInserted()
    { 
            //
            // protect rowset while we collect inserted rows
            //
        synchronized( m_jdcRowset )
        {
            return new JDCRowEnumerator( m_jdcRowset, true, false, false );
        }
    }

    public Enumeration getDeleted()
    { 
            //
            // protect rowset while we collect deleted rows
            //
        synchronized( m_jdcRowset )
        {
            return new JDCRowEnumerator( m_jdcRowset, false, true, false );
        }
    }

    public Enumeration getDirty()
    { 
            //
            // protect rowset while we collect dirty rows
            //
        synchronized( m_jdcRowset )
        {
            return new JDCRowEnumerator( m_jdcRowset, false, false, true );
        }
    }


	////////////////////////////////////////
	// executeSQL
	//
    // * creates and executes SQL statement
    // * created row data cache (JDCRowset/Vector)
    // * kicks of asynchrounous row data load
	//
	public void executeSQL()
        throws Exception
	{
        if( m_connection == null )
            throw new Exception( "Please call connect() before executeSQL()" );

		m_statement = m_connection.createStatement();
		m_resultSet = m_statement.executeQuery( m_sqlStatement );
		m_rsMeta    = m_resultSet.getMetaData();

        m_jdcRowset = new JDCRowset(m_rsMeta);
        m_async.start();
    }


	////////////////////////////////////////
	// loadNextRow
	//
    //
	private boolean loadNextRow( )
    {
        try
        {
			boolean success = m_resultSet.next();
            if( success )
            {
		        JDCRow jdcRow = new JDCRow( m_rsMeta.getColumnCount() );
                fillJDCRow( jdcRow, false /*clear*/ );

                synchronized( m_jdcRowset )
                {
                    m_jdcRowset.addElement( jdcRow );
                }

				return true;
            }
        }
        catch( Exception ex ) 
        { 
            JDC.EXCEPTIONTRACE( ex, "Exception in loadNextRow"); 
        }

        return false;
    }

	////////////////////////////////////////
	// getValueCurrentRow
	//
	private JavaVariant getValueCurrentRow( int column, boolean clear )
        throws Exception
	{
        if( column < 1 )
            throw new Exception( "Column index must be >= 1" );

		try
		{
			int typeColumn = m_rsMeta.getColumnType(column);
			switch( typeColumn )
			{
				case java.sql.Types.NUMERIC :		// java.lang.BigNum
				case java.sql.Types.DECIMAL :		// java.lang.BigNum
				case java.sql.Types.BIGINT :
                    if( clear )
                        return new JavaVariant( (long)0 );
                    else
                        return new JavaVariant( m_resultSet.getLong(column) );
				
                case java.sql.Types.INTEGER :
                    if( clear )
                        return new JavaVariant( (int)0 );
                    else
                        return new JavaVariant( m_resultSet.getInt(column) );

				case java.sql.Types.FLOAT :
				case java.sql.Types.DOUBLE :
                    if( clear )
                        return new JavaVariant( (double)0.0 );
                    else
                        return new JavaVariant( m_resultSet.getDouble(column) );

				case java.sql.Types.REAL :
                    if( clear )
                        return new JavaVariant( (float)0.0 );
                    else
                        return new JavaVariant( m_resultSet.getFloat(column) );

				case java.sql.Types.SMALLINT :
                    if( clear )
                        return new JavaVariant( (short)0.0 );
                    else
                        return new JavaVariant( m_resultSet.getShort(column) );

				case java.sql.Types.BIT :		    // bugbug ?
				case java.sql.Types.TINYINT :
                    if( clear )
                        return new JavaVariant( (byte)0 );
                    else
                        return new JavaVariant( m_resultSet.getByte(column) );

				case java.sql.Types.BINARY :		// byte[]
				case java.sql.Types.VARBINARY :		// byte[]
				case java.sql.Types.LONGVARBINARY :	// byte[]
				case java.sql.Types.TIME :			// java.sql.Time
				case java.sql.Types.TIMESTAMP :		// java.sql.Timestamp
				case java.sql.Types.DATE :			// java.sql.Date
                case java.sql.Types.CHAR :
				case java.sql.Types.LONGVARCHAR :
				case java.sql.Types.VARCHAR :
                    if( clear )
                        return new JavaVariant( "" );
                    else
                    {
                        String str = m_resultSet.getString(column);
                        if( str == null )           // NULL check NickC 08/27/97
                            str = new String("");
                        return new JavaVariant( str );
                    }

				case java.sql.Types.NULL :			// bugbug ?
				case java.sql.Types.OTHER :			// bugbug ?
                    break;
			}
		}
        catch( SQLException ex ) 
        { 
            JDC.EXCEPTIONTRACE( ex, "Exception in getValueCurrentRow"); 
        }

		return new JavaVariant();
	}

	////////////////////////////////////////
	// getVariant
	//
	public JavaVariant getVariant( int row, int col )
        throws Exception
	{
        synchronized( m_jdcRowset )
        {
            // verify that requested row & column are valid:
            //    column 0 is never valid (no row meta-data)
            //    row 0 is valid, this is meta-data request

            if( col <= 0 || row < 0 || 
                col > getColumnCount() || row > m_jdcRowset.size() )
                throw new IllegalArgumentException();

            if( row == 0 )
            {
                return new JavaVariant( m_rsMeta.getColumnName(col) );
            }
            else
            {
                return m_jdcRowset.rowAt( row-1 ).getValue( col-1 );
            }
        }
    }

	////////////////////////////////////////
	// getValue
	//
	public Object getValue( int row, int col )
        throws Exception
	{
        synchronized( m_jdcRowset )
        {
            // verify that requested row & column are valid:
            //    column 0 is never valid (no row meta-data)
            //    row 0 is valid, this is meta-data request

            if( col <= 0 || row < 0 || 
                col > getColumnCount() || row > m_jdcRowset.size() )
                throw new IllegalArgumentException();

            if( row == 0 )
            {
                return new String( m_rsMeta.getColumnName(col) );
            }
            else
            {
                return m_jdcRowset.rowAt( row-1 ).getUnderlyingValue( col-1 );
            }
        }
    }

    ////////////////////////////////////////
	// setVariant
	//
	public void setVariant( int row, int col, JavaVariant v )
        throws Exception
	{
        synchronized( m_jdcRowset )
        {
            // verify that requested row & column are valid:
            //    column 0 is never valid (no row meta-data)
            //    row 0 is valid, this is meta-data request

            if( col <= 0 || row <= 0 || 
                col > getColumnCount() || row > m_jdcRowset.size() )
                throw new IllegalArgumentException();

            JDCRow jdcRow = jdcRow = m_jdcRowset.rowAt( row-1 );
            JavaVariant vExisting = jdcRow.getValue( col-1 );
            v.changeType( vExisting.getvt() );
            jdcRow.setValue( col-1, v);
        }
    }

	////////////////////////////////////////
	// getColumnCount
	//
	public int getColumnCount()
	{
		try
		{
            return m_rsMeta.getColumnCount();
		}
		catch( SQLException ex ) 
        {
            JDC.EXCEPTIONTRACE( ex, "Exception in getColumnCount"); 
            return 0; 
        }
	}

	////////////////////////////////////////
	// getRowCount
	//
	//
    public int getRowCount()
    {
        synchronized( m_jdcRowset )
        {
            return m_useableRowsetSize;
        }
    }

    ////////////////////////////////////////
	// fillJDCRow
	//
	private void fillJDCRow( JDCRow jdcRow, boolean clear )
	{
		try
		{
			int numColumns = m_rsMeta.getColumnCount();
			for( int i=0; i < numColumns; i++ )
			{
                // i+1 because JDBC starts at 1, not zero
				JavaVariant v = getValueCurrentRow( i+1, clear );
				jdcRow.setValue( i, v );
			}
		}
		catch( Exception ex ) 
        { 
            JDC.EXCEPTIONTRACE( ex, "Exception in fillJDCRow"); 
        }
	}


    ////////////////////////////////////////
	// insertRow
	//
	public int insertRows( int row, int numRows )
        throws Exception
	{
        int numInserted = 0;
        for( int i=0; i < numRows; i++, numInserted++ )
        {
            JDCRow jdcRow = new JDCRow( getColumnCount() );
            fillJDCRow( jdcRow, true /*clear*/ );
            m_jdcRowset.insertElementAt( jdcRow, row );
        }

        if( numInserted > 0 )
            quicksortRowset();

        return numInserted;
    }

    ////////////////////////////////////////
	// insertRow
	//
	public int deleteRows( int row, int numRows )
        throws Exception
	{
        int numDeleted = 0;
        for( int i=0; i < numRows; i++, numDeleted++ )
        {
            JDCRow jdcRow = m_jdcRowset.rowAt(row-1+i);
            if( jdcRow != null )
                jdcRow.setDeleted( true );
        }

        if( numDeleted > 0 )
            quicksortRowset();

        return numDeleted;
    }

	////////////////////////////////////////
	// Method Find
	//
    //                         // These values derived from bitmasks
    //                         // i.e.       GT  LT  EQ    
    // STDCOMP_DEFAULT = 1,    // STDCOMP_EQ is the default
    // STDCOMP_EQ = 1,         // STDCOMP_EQ          1 Equal
    // STDCOMP_LT = 2,         // STDCOMP_LT      1   0 Less than
    // STDCOMP_LE = 3,         // STDCOMP_LE      1   1 Less than or equal
    // STDCOMP_GE = 4,         // STDCOMP_GT  1   0   0 Greater than or equal
    // STDCOMP_GT = 5,         // STDCOMP_GE  1   0   1 Greater than
    // STDCOMP_NE = 6,         // STDCOMP_NE  1   1   0 Not equal
    //
    // 
    public int find( int startRow, int col, JavaVariant val, int findFlags, int compType )
        throws Exception
    {
        if( startRow > m_jdcRowset.size() )
            throw new ArrayIndexOutOfBoundsException();

        int stop = m_jdcRowset.size();
        for( int i=startRow; i <= stop; i++ )
        {
            JDCRow  jdcRow  = m_jdcRowset.rowAt(i-1);
            JavaVariant v = jdcRow.getValue( col );
            int cmp = compareVariant( val, v );
            switch( compType )
            {
                case 2 :  
                    if( cmp < 0 )
                        return i;
                    break;
                case 3 :
                    if( cmp <= 0 )
                        return i;
                    break;
                case 4 :  
                    if( cmp >= 0 )
                        return i;
                    break;
                case 5 :  
                    if( cmp > 0 )
                        return i;
                    break;
                case 6 :  
                    if( cmp != 0 )
                        return i;
                    break;
                default:
                    if( cmp == 0 )
                        return i;
                    break;
            };
        }

        return -1;
    }

    ////////////////////////////////////////
	// method QuicksortRowset
	//
    public void quicksortRowset( )
        throws Exception
    {
        synchronized( m_jdcRowset )
        {
            m_useableRowsetSize = 0;

            //
            // if we don't have at least 1 row, abort
            //  
            if( m_jdcRowset.size() == 0 )
                return;

            //
            // if we have 1, and row 
            //  a) is deleted, or b) does not meet filter criterion
            //  return
            if( m_jdcRowset.size() == 1 &&
                ( m_jdcRowset.rowAt(0).getDeleted() ||
                  !rowSatisfiesFilter(m_jdcRowset.rowAt(0)) ) )
                return;

            //
            // set the meetsFilter boolean of all rows to TRUE
            //
            preProcessRowSet();

            //
            // figure out the column index to do primary sort on
            // (we store the *name* of the column, not the index)
            //
            m_qsColIndex = m_jdcRowset.getColumnIndex( m_sortColumn );
            m_filterColumnIndex = m_jdcRowset.getColumnIndex( m_filterColumn );

            //
            // to speed up filter compares, create a variant with value
            // equal to the filter value we store as a string
            //
            if( m_filterColumnIndex != -1 )
            {
                JDCRow firstRow = m_jdcRowset.rowAt(0); // any valid row will do
                m_filterValueVariant = stringToColumnVariant( m_filterColumnIndex, m_filterValue, firstRow );
            }

            quicksort( 0, m_jdcRowset.size()-1 );

            //
            // find last index that is not deleted and still meets filter criterion
            //
            postProcessRowset();
        }
    }

    ////////////////////////////////////////
	// method quicksort
	//
    private void quicksort( int i, int j )
        throws Exception
    {
        int pivotIndex = quicksortFindPivot(i,j);
        if( pivotIndex != -1 )
        {
            Object pivot = m_jdcRowset.elementAt(pivotIndex);
            int k = quicksortPartition(i,j,pivot);
            quicksort(i,k-1);
            quicksort(k,j);
        }
    }

    ////////////////////////////////////////
	// method quicksortPartition
	//
    private int quicksortPartition( int i, int j, Object pivot )
        throws Exception
    {
        int l = i;
        int r = j;
        do
        {
            quicksortSwap( l,r );

            while( quicksortCompare( m_qsColIndex, m_jdcRowset.rowAt(l), (JDCRow)pivot) < 0 )
                l++;

            while( quicksortCompare( m_qsColIndex, m_jdcRowset.rowAt(r), (JDCRow)pivot) >= 0 )
                r--;

        } 
        while( l <= r );

        return l;
    }

    ////////////////////////////////////////
	// method quicksortFindPivot
	//
    private int quicksortFindPivot( int i, int j )
        throws Exception
    {
        Object firstKey = m_jdcRowset.elementAt(i);
        for( int k=i+1; k <= j; k++ )
        {
            if( quicksortCompare( m_qsColIndex, m_jdcRowset.rowAt(k), (JDCRow)firstKey) > 0 )
                return k;
            else if( quicksortCompare( m_qsColIndex, m_jdcRowset.rowAt(k), (JDCRow)firstKey) < 0 )
                return i;
        }
        
        return -1;
    }


    ////////////////////////////////////////
	// method quicksortSwap
	//
    private void quicksortSwap( int l, int r )
        throws Exception
    {
        Object tmp = m_jdcRowset.elementAt( l );
        m_jdcRowset.setElementAt( m_jdcRowset.elementAt( r ), l );
        m_jdcRowset.setElementAt( tmp, r );
    }


	////////////////////////////////////////
	// method quicksortCompare
	//
    private int quicksortCompare( int colIndex, JDCRow lhs, JDCRow rhs )
        throws Exception
    {
        //
        // compare deleted flags
        //
        if( lhs.getDeleted() == lhs.getDeleted() )
        {
            // compare based on filter
            boolean lhsFilt = lhs.getMeetsFilter() && rowSatisfiesFilter( lhs );
            boolean rhsFilt = rhs.getMeetsFilter() && rowSatisfiesFilter( rhs );
            if( lhsFilt == rhsFilt )
            {
                //
                // lastly, compare variant values if colIndex != -1
                //  or compare row
                //
                if( colIndex != -1 )
                {    
                    JavaVariant vLhs = lhs.getValue(colIndex);
                    JavaVariant vRhs = rhs.getValue(colIndex);
    		        return m_sortDir*compareVariant( vLhs, vRhs );
                }
                else if( lhs.getOriginalRowNum() < rhs.getOriginalRowNum() )
                    return -1;
                else if( lhs.getOriginalRowNum() == rhs.getOriginalRowNum() )
                    return 0;
                else
                    return 1;
            }
            else if( lhsFilt )
                return -1;
            else
                return 1;
        }
        else if( lhs.getDeleted() )
            return 1; // left is more (to end of vector)
        else
            return -1; // left is less (to beginning of vector)
    }

	////////////////////////////////////////
	// method rowSatisfiesFilter
	//
    // see Find to see what the criterion constants mean
    //
    boolean rowSatisfiesFilter( JDCRow row )
        throws Exception
    {
        if( m_filterColumnIndex == -1 )
            return true;

        JavaVariant v = row.getValue(m_filterColumnIndex); // bugbug?: took out -1
        
        int comp = compareVariant( v, m_filterValueVariant );
        boolean ret = false;
        switch( m_filterCriterion )
        {
            // STDCOMP_DEFAULT = 1,    // STDCOMP_EQ is the default
            // STDCOMP_EQ = 1,         // STDCOMP_EQ          1 Equal
            // STDCOMP_LT = 2,         // STDCOMP_LT      1   0 Less than
            // STDCOMP_LE = 3,         // STDCOMP_LE      1   1 Less than or equal
            // STDCOMP_GE = 4,         // STDCOMP_GT  1   0   0 Greater than
            // STDCOMP_GT = 5,         // STDCOMP_GE  1   0   1 Greater than or equal
            // STDCOMP_NE = 6,         // STDCOMP_NE  1   1   0 Not equal
            case 1 :
                ret = comp == 0;
                break;
            case 2 :
                ret = comp < 0;
                break;
            case 3 :
                ret = comp <= 0;
                break;
            case 4 :
                ret = comp >= 0;
                break;
            case 5 :
                ret = comp > 0;
                break;
            case 6 :
                ret = comp != 0;
                break;
        };

        // for sorting optimization, we skip checks to 'does meet filter' if this is 0
        if( !ret )
            row.setMeetsFilter( false );

        return ret;
    }

	////////////////////////////////////////
	// method compareVariant
	//
    private static int compareVariant( JavaVariant lhs, JavaVariant rhs )
        throws Exception
    {
        if( lhs.getvt() != rhs.getvt() )
            throw new Exception( "variant types must be equal" );

        switch( lhs.getvt() )
        {
            case JavaVariant.VariantByte :
            case JavaVariant.VariantBoolean :
            case JavaVariant.VariantShort :
                return compareLong( (long)lhs.getShort(), (long)rhs.getShort() );
            
            case JavaVariant.VariantInt :
                return compareLong( (long)lhs.getInt(), (long)rhs.getInt() );
            
            case JavaVariant.VariantFloat :
                return compareDouble( (double)lhs.getFloat(), (double)rhs.getFloat() );
            
            case JavaVariant.VariantDouble :
            case JavaVariant.VariantCurrency :
                return compareDouble( lhs.getDouble(), rhs.getDouble() );

            case JavaVariant.VariantDate :
            case JavaVariant.VariantString :
            case JavaVariant.VariantArray :
                return lhs.getString().compareTo(rhs.getString());

            case JavaVariant.VariantEmpty :
            case JavaVariant.VariantNull :
            case JavaVariant.VariantDispatch :
            case JavaVariant.VariantError :
            case JavaVariant.VariantVariant :
            case JavaVariant.VariantObject :
            case JavaVariant.VariantTypeMask :
            case JavaVariant.VariantByref :
            default:
                throw new Exception( "Bad Variant type for compare" );
        }
    }
	////////////////////////////////////////
	// method stringToColumnVariant
	//

    JavaVariant stringToColumnVariant( int filterColumn, String filterValue,
        JDCRow jdcRow )
    {
        JavaVariant filtV = new JavaVariant( filterValue );
        JavaVariant colV  = jdcRow.getValue( filterColumn );
        filtV.changeType( colV.getvt() );
        return filtV;
    }

	////////////////////////////////////////
	// method compareLong
	//
    private static int compareLong( long lhs, long rhs )
    {
        if( lhs < rhs )
            return -1;
        else if( lhs == rhs )
            return 0;
        else
            return 1;
    }

	////////////////////////////////////////
	// method compareDouble
	//
    private static int compareDouble( double lhs, double rhs )
    {
        if( lhs < rhs )
            return -1;
        else if( lhs == rhs )
            return 0;
        else
            return 1;
    }

	////////////////////////////////////////
	// method postProcessRowset
	//
    private void postProcessRowset()
    {
        int rowsetSize = m_jdcRowset.size();
        for( m_useableRowsetSize = 0; m_useableRowsetSize < rowsetSize; m_useableRowsetSize++ )
        {
            if( m_jdcRowset.rowAt(m_useableRowsetSize).getMeetsFilter() == false )
                return;

            if( m_jdcRowset.rowAt(m_useableRowsetSize).getDeleted() == true )
                return;
        }
    }

	////////////////////////////////////////
	// method preprocessRowSet
	//
    private void preProcessRowSet()
    {
        int rowsetSize = m_jdcRowset.size();
        for( int i= 0; i < rowsetSize; i++ )
            m_jdcRowset.rowAt(i).setMeetsFilter( true );
    }

    ////////////////////////////////////////
	// stopTransfer
	//
	// @return 
	//
    public void stopTransfer()
	{
        m_fContinueTransfer = false;
	}

    ////////////////////////////////////////
	// getEstimatedRows
	//
	// @return 
	//
	public int getEstimatedRows()
    {
        if( m_fContinueTransfer == false )
        {
                //
                // return the real size in this case, since we stopped transferring
                //
            return m_useableRowsetSize;
        }
        else
        {
                //
                // otherwise, return preload rows
                //
            if( m_preloadRows < 0 )
                return 0;
            else
                return m_preloadRows;
        }
    }


	//
	// ICustomCriterion implementation
	//
	
	////////////////////////////////////////
	// dbURL Property : ICustomCriterion
	//
	//
	public String getDbURL()
        { return m_dbURL; }

	public void setDbURL( String dburl )
        { m_dbURL = dburl; }

	////////////////////////////////////////
	// preloadRows Property : ICustomCriterion
    //
	public int getPreloadRows()
        { return m_preloadRows; }

	public void setPreloadRows( int iPreload )
        { m_preloadRows = iPreload; }

	////////////////////////////////////////
	// sqlStatement Property : ICustomCriterion
	//
	public String getSQLStatement()
        { return m_sqlStatement; }

	public void setSQLStatement( String sqlStatement )
        { m_sqlStatement = sqlStatement; }

	////////////////////////////////////////
	// sortColumn Property : ICustomCriterion
	//
	public String getSortColumn()
        { return m_sortColumn; }

	public void setSortColumn( String sortCol )
        { m_sortColumn = sortCol; }

	////////////////////////////////////////
	// sortDirection Property : ICustomCriterion
	//
	public String getSortDirection()
    { 
        if( m_sortDir == 1 )
            return "Ascending";
        else
            return "Descending";
    }

	public void setSortDirection( String sortDir )
    { 
            //
            // since we almost always want ascending, be forgiving
            // by specifically checking for very few descending strings
            //
        if( sortDir.equalsIgnoreCase("Descending") ||
            sortDir.equalsIgnoreCase("Down") )
            m_sortDir = -1;
        else
            m_sortDir = 1; 

    }

	////////////////////////////////////////
	// filterColumn Property : ICustomCriterion
	//
	public String getFilterColumn()
        { return m_filterColumn; }

	public void setFilterColumn( String filtCol )
        { m_filterColumn = filtCol; }

	////////////////////////////////////////
	// filterCriterion Property : ICustomCriterion
	//
	public String getFilterCriterion()
    { 
        //
        // -1 represents no criterion specified, so return a null stirng
        // otherwise reyurn the preset strings stored in m_filterCriterionStrings
        //
        if( m_filterCriterion == -1 )
            return "";
        else
            return m_filterCriterionStrings[m_filterCriterion];
    }

	public void setFilterCriterion( String filterCrit )
    { 
        // 
        // We store filter criterion as an enum (int). Search for the
        // correct enum value based on a search through the strings
        // of m_filterCriterionStrings
        //
        m_filterCriterion = -1;
        
        for( int i=1; i <= 6; i++ )
        {
            if( m_filterCriterionStrings[i].equals(filterCrit) )
            {
                m_filterCriterion = i; 
                break;
            }
        }

    }

	////////////////////////////////////////
	// filterValue Property : ICustomCriterion
	//
	public String getFilterValue()
        { return m_filterValue; }

	public void setFilterValue( String filtVal )
        { m_filterValue = filtVal; }

	////////////////////////////////////////
	// user Property : ICustomCriterion
	//
	public String  getUser()
		{ return m_userName; }

	public void  setUser( String userName )
		{ m_userName = userName; }

	////////////////////////////////////////
	// password Property : ICustomCriterion
	//
	public String getPassword()
		{ return m_userPassword; }

	public void setPassword( String userPassword )
		{ m_userPassword = userPassword; }

} // JDCDataAccess

