//=--------------------------------------------------------------------------=
// Copyright  1997  Microsoft Corporation.  All Rights Reserved.
//
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//=--------------------------------------------------------------------------=
//
// @(#)JavaVariant
//
// Pure Java Implementation of com.ms.com.Variant [native] class
//
//  'to-do' comments where functionality absent
// 
//

public final class JavaVariant
{   
        //
        // variant type constants
        //
    public static final short VariantEmpty    = 0;
    public static final short VariantNull     = 1;       
    public static final short VariantShort    = 2;       
    public static final short VariantInt      = 3;       
    public static final short VariantFloat    = 4;       
    public static final short VariantDouble   = 5;       
    public static final short VariantCurrency = 6;       
    public static final short VariantDate     = 7;       
    public static final short VariantString   = 8;       
    public static final short VariantDispatch = 9;       
    public static final short VariantError    = 10;      
    public static final short VariantBoolean  = 11;      
    public static final short VariantVariant  = 12;      
    public static final short VariantObject	  = 13;      
    public static final short VariantByte	  = 17;      
    public static final short VariantTypeMask = 4095;    
    public static final short VariantArray	  = 8192;    
    public static final short VariantByref	  = 16384;   

    private Object m_value = null;
    private short  m_vt    = VariantEmpty;

    ////////////////////////////////////////
    // ctor
    //
    public JavaVariant() {}

    ////////////////////////////////////////
    // ctor
    //
    public JavaVariant( Object obj ) 
    {
        try
        {
            if( obj == null )
            {
                putNull();
                return;
            }

            Class cls = obj.getClass();
            String str = cls.getName();
            if( cls == Class.forName( "java.lang.String" ) )
                putString( (String)obj );
            else if( cls == Class.forName( "java.lang.Integer" ) )
                putInt( ((Integer)obj).intValue() );
            else if( cls == Class.forName( "java.lang.Float" ) )
                putFloat( ((Float)obj).floatValue() );
            else if( cls == Class.forName( "java.lang.Double" ) )
                putDouble( ((Double)obj).doubleValue() );
            else if( cls == Class.forName( "java.lang.Byte" ) )
                putByte( ((Byte)obj).byteValue() );
            else if( cls == Class.forName( "java.lang.Character" ) )
                putByte( (byte)((Character)obj).charValue());
            else if( cls == Class.forName( "java.lang.Boolean" ) )
                putBoolean( ((Boolean)obj).booleanValue() );
            else if( cls == Class.forName( "java.lang.Long" ) )
                putInt( ((Long)obj).intValue() );
            else if( cls == Class.forName( "java.lang.Number" ) )
                putDouble( ((Number)obj).doubleValue() );
            else
                putString( obj.toString() );
        }
        catch( ClassNotFoundException ex )
        {
            putString( obj.toString() );
        }
    }

    ////////////////////////////////////////
    // ctor
    //
    public JavaVariant( String str )
    {
        try
        {
            m_value = str.intern();
            m_vt = VariantString;
        }
        catch( CloneNotSupportedException ex )
        {
            m_value = str;
            m_vt = VariantString | VariantByref;
        }
    }

    ////////////////////////////////////////
    // ctor
    //
    // we do not support 64-bit int so use 32-bit Java 'Integer'
    public JavaVariant( long val )
    {
        putInt( (int)val );
    }

    ////////////////////////////////////////
    // ctor
    //
    public JavaVariant( int val )
    {
        putInt( val );
    }

    ////////////////////////////////////////
    // ctor
    //
    public JavaVariant( short val )
    {
        putShort( val );
    }

    ////////////////////////////////////////
    // ctor
    //
    public JavaVariant( float val )
    {
        putFloat( val );
    }

    ////////////////////////////////////////
    // ctor
    //
    public JavaVariant( double val )
    {
        putDouble( val );
    }

    ////////////////////////////////////////
    // 
    //
    public void changeType( short varType )
    {
        switch( varType )
        {
            case VariantShort:
                putShort( getShort() );
                break;
            case VariantInt:
                putInt( getInt() );
                break;
            case VariantFloat:
                putFloat( getFloat() );
                break;
            case VariantDate:
                putDate( getDate() );
                break;
            case VariantDouble:
                putDouble( getDouble() );
                break;
            case VariantString:
                putString( getString() );
                break;
            case VariantBoolean:
                putBoolean( getBoolean() );
                break;
            case VariantByte:
                putByte( getByte() );
                break;
            case VariantCurrency:
                putCurrency( getCurrency() );
                break;
            case VariantDispatch:
                putDispatch( getDispatch() );
                break;
            case VariantError:
                putError( getError() );
                break;
            //case VariantVariant:
            //    putVariant( getVariant() );
            //    break;
            case VariantEmpty:
                putEmpty();
                break;
            case VariantNull:
                putNull();
                break;
            case VariantObject:
                putObject( getObject() );
                break;
            //case VariantTypeMask:
            //    putTypeMask( getTypeMask() );
            //    break;
            //case VariantArray:
            //    putArray( getArray() );
            //    break;
        }
    }

    ////////////////////////////////////////
    // clone
    //
    // @returns a new copy of the javaVariant, with a reference
    //  to the underlying data item
    //
    public JavaVariant clone()
    {
        JavaVariant v = new JavaVariant();

        if( m_value != null )
        {
            v.m_value = m_value;
            v.m_vt = (short)(m_vt | VariantByref);
        }

        return v;
    }

    ////////////////////////////////////////
    // clone
    //
    // @returns a new copy of the javaVariant, with a new copy
    //  to the underlying data item
    //
    public JavaVariant cloneIndirect()
    {
        JavaVariant v = new JavaVariant();

        if( m_value != null )
        {
            try
            {
                v.m_value = m_value.clone();
                v.m_vt = m_vt;
            }
            catch( CloneNotSupportedException ex )
            {
            }
        }

        return v;
    }

    ////////////////////////////////////////
    //
    //
    //
    public Object getValue()
    {
        return m_value;
    }

    ////////////////////////////////////////
    // finalize
    //
    // clears the variant
    //
    protected void finalize()
    {
        m_value = null;
        m_vt = VariantEmpty;
    }

    ////////////////////////////////////////
    // getvt 
    //
    // returns the type of the variant as an short enum
    //
    public short getvt()
    {
        return m_vt;
    }

    ////////////////////////////////////////
    // getEmpty
    //
    public void getEmpty() {}

    ////////////////////////////////////////
    // getNull
    //
    public void getNull() {}

    ////////////////////////////////////////
    // 
    //
    public short getShort()
    {
        return (short)getInt();
    }

    ////////////////////////////////////////
    // 
    //
    public int getInt()
    {
        switch( m_vt )
        {
            case VariantShort:
            case VariantInt:
                return ((Integer)m_value).intValue();
            case VariantFloat:
                return ((Float)m_value).intValue();
            case VariantDate:
            case VariantDouble:
                return ((Double)m_value).intValue();
            case VariantString:
                return Integer.valueOf((String)m_value).intValue();
            case VariantBoolean:
                if( ((Boolean)m_value).booleanValue() == true )
                    return 1;
                else
                    return 0;
            case VariantByte:
                return ((Character)m_value).charValue();
            case VariantCurrency:
                return ((Long)m_value).intValue();

            case VariantDispatch:
            case VariantError:
            case VariantVariant:
            case VariantEmpty:
            case VariantNull:
            case VariantObject:
            case VariantTypeMask:
            case VariantArray:
            case VariantByref:
            default:
                return 0;
        }
    }

    ////////////////////////////////////////
    // 
    //
    public float getFloat()
    {
        return (float)getDouble();
    }

    ////////////////////////////////////////
    // 
    //
    public double getDouble()
    {
        switch( m_vt )
        {
            case VariantShort:
            case VariantInt:
                return (double)((Integer)m_value).intValue();
            case VariantFloat:
                return ((Float)m_value).doubleValue();
            case VariantDouble:
                return ((Double)m_value).doubleValue();
            case VariantString:
                return Double.valueOf((String)m_value).doubleValue();
            case VariantBoolean:
                if( ((Boolean)m_value).booleanValue() == true )
                    return 1.0;
                else
                    return 0.0;
            case VariantByte:
                return (double)((Character)m_value).charValue();
            case VariantCurrency:
                return ((Long)m_value).doubleValue();

            case VariantDate:
            case VariantDispatch:
            case VariantError:
            case VariantVariant:
            case VariantEmpty:
            case VariantNull:
            case VariantObject:
            case VariantTypeMask:
            case VariantArray:
            case VariantByref:
            default:
                return 0.0;
        }
    }

    ////////////////////////////////////////
    // 
    //
    public long getCurrency()
    {
        return (long)getInt();
    }

    ////////////////////////////////////////
    // 
    //
    public double getDate()
    {
        return getDouble();
    }

    ////////////////////////////////////////
    // 
    //
    public String getString()
    {
        switch( m_vt )
        {
            case VariantShort:
            case VariantInt:
                return ((Integer)m_value).toString();
            case VariantFloat:
                return ((Float)m_value).toString();
            case VariantDouble:
                return ((Double)m_value).toString();
            case VariantString:
                return ((String)m_value).intern();
            case VariantBoolean:
                return ((Boolean)m_value).toString();
            case VariantByte:
                return ((Character)m_value).toString();
            case VariantCurrency:
                return ((Long)m_value).toString();

            case VariantDate:
            case VariantDispatch:
            case VariantError:
            case VariantVariant:
            case VariantEmpty:
            case VariantNull:
            case VariantObject:
            case VariantTypeMask:
            case VariantArray:
            case VariantByref:
            default:
                return "";
        }
    }

    ////////////////////////////////////////
    // 
    //
    public Object getDispatch()
    {
        return null;
    }

    ////////////////////////////////////////
    // 
    //
    public int getError()
    {
        return 0;
    }

    ////////////////////////////////////////
    // 
    //
    public boolean getBoolean()
    {
        return false;
    }

    ////////////////////////////////////////
    // 
    //
    public Object getObject()
    {
        return null;
    }

    ////////////////////////////////////////
    // 
    //
    public byte getByte()
    {
        return 0;
    }

    ////////////////////////////////////////
    // 
    //
    public short getShortRef()
    {
        return 0;
    }

    ////////////////////////////////////////
    // 
    //
    public int getIntRef()
    {
        return 0;
    }

    ////////////////////////////////////////
    // 
    //
    public float getFloatRef()
    {
        return 0;
    }

    ////////////////////////////////////////
    // 
    //
    public double getDoubleRef()
    {
        return 0.0;
    }

    ////////////////////////////////////////
    // 
    //
    public long getCurrencyRef()
    {
        return 0;
    }

    ////////////////////////////////////////
    // 
    //
    public double getDateRef()
    {
        return 0.0;
    }

    ////////////////////////////////////////
    // 
    //
    public String getStringRef()
    {
        return "";
    }

    ////////////////////////////////////////
    // 
    //
    public Object getDispatchRef()
    {
        return null;
    }

    ////////////////////////////////////////
    // 
    //
    public int getErrorRef()
    {
        return 0;
    }

    ////////////////////////////////////////
    // 
    //
    public boolean getBooleanRef()
    {
        return false;
    }

    ////////////////////////////////////////
    // 
    //
    public Object getObjectRef()
    {
        return null;
    }

    ////////////////////////////////////////
    // 
    //
    public byte getByteRef()
    {
        return 0;
    }

    ////////////////////////////////////////
    // 
    //
    public void noParam()
    {
    }

    ////////////////////////////////////////
    // 
    //
    public void putEmpty()
    {
        m_value = null;
        m_vt = VariantEmpty;
    }

    ////////////////////////////////////////
    // 
    //
    public void putNull()
    {
        m_value = null;
        m_vt = VariantNull;
    }

    ////////////////////////////////////////
    // 
    //
    public void putShort(short val)
    {
        m_value = new Short(val);
        m_vt = VariantShort;
    }

    ////////////////////////////////////////
    // 
    //
    public void putInt(int val)
    {
        m_value = new Integer(val);
        m_vt = VariantInt;
    }

    ////////////////////////////////////////
    // 
    //
    public void putFloat(float val)
    {
        m_value = new Float(val);
        m_vt = VariantFloat;
    }

    ////////////////////////////////////////
    // 
    //
    public void putDouble(double val)
    {
        m_value = new Double(val);
        m_vt = VariantDouble;
    }

    ////////////////////////////////////////
    // 
    //
    public void putCurrency(long val)
    {
        m_value = new Long(val);
        m_vt = VariantInt;
    }

    ////////////////////////////////////////
    // 
    //
    public void putDate(double val)
    {
        m_value = new Double(val);
        m_vt = VariantDouble;
    }

    ////////////////////////////////////////
    // 
    //
    public void putString(String val)
    {
        m_value = new String(val);
        m_vt = VariantString;
    }

    ////////////////////////////////////////
    // 
    //
    public void putDispatch(Object val)
    {
        try
        {
            m_value = val.clone();
            m_vt = VariantDispatch;
        }
        catch( CloneNotSupportedException ex )
        {
            m_value = val;
            m_vt = VariantDispatch | VariantByref;
        }
    }

    ////////////////////////////////////////
    // 
    //
    public void putError(int val)
    {
        m_value = new Integer(val);
        m_vt = VariantError;
    }

    ////////////////////////////////////////
    // 
    //
    public void putBoolean(boolean val)
    {
        m_value = new Boolean(val);
        m_vt = VariantBoolean;
    }

    ////////////////////////////////////////
    // 
    //
    public void putObject(Object val)
    {
        try
        {
            m_value = val.clone();
            m_vt = VariantObject;
        }
        catch( CloneNotSupportedException ex )
        {
            m_value = val;
            m_vt = VariantObject | VariantByref;
        }
    }

    ////////////////////////////////////////
    // 
    //
    public void putByte(byte val)
    {
        m_value = new Character((char)val);
        m_vt = VariantByte;
    }

    ////////////////////////////////////////
    // 
    //
    public void putShortRef(short val)
    {
        m_value = new Short(val);
        m_vt = VariantShort | VariantByref;
    }

    ////////////////////////////////////////
    // 
    //
    public void putIntRef(int val)
    {
        m_value = new Integer(val);
        m_vt = VariantInt | VariantByref;
    }

    ////////////////////////////////////////
    // 
    //
    public void putFloatRef(float val)
    {
        m_value = new Float(val);
        m_vt = VariantFloat | VariantByref;
    }

    ////////////////////////////////////////
    // 
    //
    public void putDoubleRef(double val)
    {
        m_value = new Double(val);
        m_vt = VariantDouble | VariantByref;
    }

    ////////////////////////////////////////
    // 
    //
    public void putCurrencyRef(long val)
    {
        m_value = new Long(val);
        m_vt = VariantInt | VariantByref;
    }

    ////////////////////////////////////////
    // 
    //
    public void putDateRef(double val)
    {
        m_value = new Double(val);
        m_vt = VariantDouble | VariantByref;
    }

    ////////////////////////////////////////
    // 
    //
    public void putStringRef(String val)
    {
        m_value = val;
        m_vt = VariantString | VariantByref;
    }

    ////////////////////////////////////////
    // 
    //
    public void putDispatchRef(Object val)
    {
        m_value = val;
        m_vt = VariantDispatch | VariantByref;
    }

    ////////////////////////////////////////
    // 
    //
    public void putErrorRef(int val)
    {
        m_value = new Integer(val);
        m_vt = VariantError | VariantByref;
    }

    ////////////////////////////////////////
    // 
    //
    public void putBooleanRef(boolean val)
    {
        m_value = new Boolean(val);
        m_vt = VariantBoolean | VariantByref;
    }

    ////////////////////////////////////////
    // 
    //
    public void putObjectRef(Object val)
    {
        m_value = val;
        m_vt = VariantObject | VariantByref;
    }

    ////////////////////////////////////////
    // 
    //
    public void putByteRef(byte val)
    {
        m_value = new Character((char)val);
        m_vt = VariantByte | VariantByref;
    }

    ////////////////////////////////////////
    // 
    //
    public short toShort()
    {
        return 10;
    }

    ////////////////////////////////////////
    // 
    //
    public int toInt()
    {
        return 10;
    }

    ////////////////////////////////////////
    // 
    //
    public float toFloat()
    {
        return (float)10.0;
    }

    ////////////////////////////////////////
    // 
    //
    public double toDouble()
    {
        return (float)10.0;
    }

    ////////////////////////////////////////
    // 
    //
    public long toCurrency()
    {
        return 10;
    }

    ////////////////////////////////////////
    // 
    //
    public double toDate()
    {
        return 10.0;
    }

    ////////////////////////////////////////
    // 
    //
    public String toString()
    {
        return m_value.toString();
    }

    ////////////////////////////////////////
    // 
    //
    public Object toDispatch()
    {
        return m_value;
    }

    ////////////////////////////////////////
    // 
    //
    public int toError()
    {
        return 0;
    }

    ////////////////////////////////////////
    // 
    //
    public boolean toBoolean()
    {
        return false;
    }

    ////////////////////////////////////////
    // 
    //
    public Object toObject()
    {
        return m_value;
    }

    ////////////////////////////////////////
    // 
    //
    public byte toByte()
    {
        return 0;
    }

    ////////////////////////////////////////
    // 
    //
    public void VariantClear()
    {
        m_value = null;
        m_vt = VariantEmpty;
    }
}
