//=--------------------------------------------------------------------------=
// Copyright  1997  Microsoft Corporation.  All Rights Reserved.
//
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//=--------------------------------------------------------------------------=
//
// @(#)Elements and Element collections - 03/25/97
//
// Part of the Java Data Connector
//
//

import java.util.Vector;
import java.util.Enumeration;
import java.sql.*;

////////////////////////////////////////////////////////////////////////////////
//
// class JDCRowset
//
class JDCRowset extends Vector
{
    // simple holder for column names
    private ResultSetMetaData m_rsMetaData = null;

    ////////////////////////////////////////
    // JDCRowset ctor
    //
    // This ctor creates a sentinel row  that stores meta-data
    //
    JDCRowset( ResultSetMetaData metaData )
    {
        m_rsMetaData = metaData;
    }

    ////////////////////////////////////////
    // getColumnIndex
    //
    // @return 0-based column index (not 1-based jdbc col index)
    //      that matches the specified column name
    //
    public int getColumnIndex( String strColumnName )
    {
        try
        {
            int numColumns = m_rsMetaData.getColumnCount();
            for( int i=0; i < numColumns; i++ )
            {
			    String colName = m_rsMetaData.getColumnName(i+1);
                if( colName.equalsIgnoreCase( strColumnName ) )
                    return i;
            }
        }
        catch( SQLException ex )
        {
            JDC.EXCEPTIONTRACE( ex, "Error in column index" );
        }

        return -1; // no match
    }


    ////////////////////////////////////////
    // rowAt
    //
    // @return a JDCRow object at specified position
    //
    public JDCRow rowAt( int index )
    {
        return (JDCRow)elementAt(index);
    }
}





////////////////////////////////////////////////////////////////////////////////
//
// class JDCRowEnumerator
//
// Use to help developers implement the commitChanges() applet member
//
class JDCRowEnumerator implements Enumeration
{
    // next index to return with a call to mnextElement()
    private int m_next;

    // out container for cells that match criteria specified in ctor
    private Vector elements = new Vector();

    ////////////////////////////////////////
    // JDCRowEnumerator ctor
    //
    // Creates a new vector from jdcRowset that contains all of its
    // elements unless any of addIfInserted, addIfDeleted, or addIfDirty
    // are true. If true, we only add rows that have the appropriate flag 
    // set
    //
    JDCRowEnumerator( JDCRowset jdcRowset, 
        boolean addIfInserted, boolean addIfDeleted, boolean addIfDirty )
    {
        m_next = 0;

        //
        // add elements of jdcRowset to our vector
        //
        int count = jdcRowset.size();
        for( int i=0; i < count; i++ )
        {
            JDCRow row = jdcRowset.rowAt(i);
            
            //
            // skip add if a condition was specified and was not met
            // (false in any condition means ignore)
            //
            if( addIfInserted && !row.getInserted() )
                continue;

            if( addIfDeleted && !row.getDeleted() )
                continue;

            if( addIfDirty && !row.getDirty() )
                continue;
            
            elements.addElement( row );
        }
    }

    ////////////////////////////////////////
    // hasMoreElements
    //
    // @return whether the enumerator has more elements
    //
    public boolean hasMoreElements()
    {
        return m_next < elements.size();
    }

    ////////////////////////////////////////
    // nextElement
    //
    // @return the next object in t he enumeration
    //
    public Object nextElement()
    {
        Object ret = null;
        if( m_next < elements.size() )
            ret = elements.elementAt(m_next);
        m_next++;
        return ret;
    }

}




////////////////////////////////////////////////////////////////////////////////
//
// class JDCRow
//
// JDCRow encapsulates: a) the cells that make up a row of data
//                      b) the inserted, deleted, dirty states of the row
//
class JDCRow extends Vector
{
	private static int m_nextRowNum  = 0;
	private int     m_originalRowNum = -1;
	private boolean m_dirty       = false;
	private boolean m_inserted    = false;
	private boolean m_deleted     = false;
	private boolean m_meetsFilter = true;

	////////////////////////////////////////
	// ctor
	//
	public JDCRow( int cols )
	{
        //
        // create empty cells
        //
		ensureCapacity( cols );
		for( int i=0; i < cols; i++ )
			addElement( new JDCCell() );

        // assign our instances m_originalRowNum to the static
        //   row count. This static row count will always be generating a 
        //   unique row number so we can order rows in their original order
        //   later
        m_originalRowNum = m_nextRowNum++;
	}

	////////////////////////////////////////
	// Value
	//
	public void setValue( int col, JavaVariant v )
        throws ArrayIndexOutOfBoundsException
	{
		((JDCCell)elementAt( col )).setValue( v );
	}

	public JavaVariant getValue( int col )
	{
		return ((JDCCell)elementAt( col )).getValue();
	}

	////////////////////////////////////////
	// Underlying value
	//
	public Object getUnderlyingValue( int col )
	{
		return ((JDCCell)elementAt( col )).getUnderlyingValue();
	}

	////////////////////////////////////////
	// Dirty
	//
	public boolean getDirty( )
        { return m_dirty; }

	public void setDirty( boolean dirty )
	    { m_dirty = dirty; }

	////////////////////////////////////////
	// Inserted
	//
	public boolean getInserted( )
        { return m_inserted; }

	public void setInserted( boolean  inserted )
        { m_inserted = inserted; }

	////////////////////////////////////////
	// Deleted
	//
	public boolean getDeleted( )
        { return m_deleted;	}

	public void setDeleted( boolean deleted )
        { m_deleted = deleted;	}

	////////////////////////////////////////
	// MeetsFilter
	//
	public boolean getMeetsFilter( )
        { return m_meetsFilter; }

	public void setMeetsFilter( boolean meetsFilter )
        { m_meetsFilter = meetsFilter; }

	////////////////////////////////////////
	// OriginalRowNum
	//
	public int getOriginalRowNum( )
        { return m_originalRowNum; }

	public void setOriginalRowNum( int originalRowNum )
	    {   m_originalRowNum = originalRowNum;	}


} // class JDCRow








////////////////////////////////////////////////////////////////////////////////
//
// class JDCCell
//
// JDCCell encapsulates: a) the cell's Variant data
//                       b) the cell's dirty state
// 
class JDCCell
{
    private JavaVariant m_value = new JavaVariant();
	private boolean m_dirty = false;

	////////////////////////////////////////
	// ctor
	//
	public JDCCell()
        { m_value.putEmpty(); }

	////////////////////////////////////////
	// getUnderlyingValue
	//
	public Object getUnderlyingValue()
        { return m_value.getValue(); }

	////////////////////////////////////////
	// getData
	//
	public JavaVariant getValue()
        { return m_value; }

	////////////////////////////////////////
	// getData
	//
	public void setValue( JavaVariant v )
        { m_value = v; }

	////////////////////////////////////////
	// getDirty
	//
	public boolean getDirty()
        { return m_dirty; }

	////////////////////////////////////////
	// setDirty
	//
	public void setDirty( boolean dirty )
        { m_dirty = dirty; }

} // class JDCCell

